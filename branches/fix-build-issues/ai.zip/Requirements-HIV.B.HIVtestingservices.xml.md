# HIV testing services - XML Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **HIV testing services**

## : HIV testing services - XML Representation

| |
| :--- |
| Active as of 2026-03-03 |

[Raw xml](Requirements-HIV.B.HIVtestingservices.xml) | [Download](Requirements-HIV.B.HIVtestingservices.xml)

