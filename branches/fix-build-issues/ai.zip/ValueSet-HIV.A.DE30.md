# Marital Status ValueSet - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Marital Status ValueSet**

## ValueSet: Marital Status ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/ValueSet/HIV.A.DE30 | *Version*:0.4.4 |
| Active as of 2026-03-03 | *Computable Name*:HIVADE30 |

 
Value set of client's current marital status 

 **References** 

* [HIV.A Registration](StructureDefinition-HIVARegistration.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Marital Status ValueSet Schema API

JSON Schema for Marital Status ValueSet ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-HIV.A.DE30.schema.json

#### JSON Schema definition for the enumeration ValueSet-HIV.A.DE30

This endpoint serves the JSON Schema definition for the enumeration ValueSet-HIV.A.DE30.

## Schema Definition

### ValueSet-HIV.A.DE30

**Description:** JSON Schema for Marital Status ValueSet ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HIV.A.DE30",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"]
  },
  "url" : "http://smart.who.int/hiv/ValueSet/HIV.A.DE30",
  "version" : "0.4.4",
  "name" : "HIVADE30",
  "title" : "Marital Status ValueSet",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-03-03T20:39:19+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Value set of client's current marital status ",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/hiv/CodeSystem/HIVConcepts",
      "concept" : [{
        "code" : "HIV.A.DE31",
        "display" : "Unmarried"
      },
      {
        "code" : "HIV.A.DE32",
        "display" : "Never married"
      },
      {
        "code" : "HIV.A.DE33",
        "display" : "Married"
      },
      {
        "code" : "HIV.A.DE34",
        "display" : "Polygamous"
      },
      {
        "code" : "HIV.A.DE35",
        "display" : "Divorced"
      },
      {
        "code" : "HIV.A.DE36",
        "display" : "Widowed"
      },
      {
        "code" : "HIV.A.DE37",
        "display" : "Unknown"
      },
      {
        "code" : "HIV.A.DE38",
        "display" : "Domestic partner"
      },
      {
        "code" : "HIV.A.DE39",
        "display" : "Annulled"
      },
      {
        "code" : "HIV.A.DE40",
        "display" : "Legally separated"
      },
      {
        "code" : "HIV.A.DE41",
        "display" : "Interlocutory"
      }]
    }]
  }
}

```
