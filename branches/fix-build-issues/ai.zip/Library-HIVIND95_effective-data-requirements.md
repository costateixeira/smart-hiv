# Library - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**HIV.IND.95 Invasive cervical cancer treatment**](Measure-HIVIND95.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/Measure/HIVIND95#effective-data-requirements | *Version*:0.4.4 |
| Draft | *Computable Name*:EffectiveDataRequirements |

