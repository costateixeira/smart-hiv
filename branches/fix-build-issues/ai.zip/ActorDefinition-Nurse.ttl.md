# Nurse - TTL Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Nurse**

## : Nurse - TTL Representation

| |
| :--- |
| Draft as of 2026-03-03 |

[Raw ttl](ActorDefinition-Nurse.ttl) | [Download](ActorDefinition-Nurse.ttl)

