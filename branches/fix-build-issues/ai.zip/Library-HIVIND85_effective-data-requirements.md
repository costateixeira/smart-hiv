# Library - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**HIV.IND.85 HBsAg positivity, HIV prevention services**](Measure-HIVIND85.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/hiv/Measure/HIVIND85#effective-data-requirements | *Version*:0.4.4 |
| Draft | *Computable Name*:EffectiveDataRequirements |

