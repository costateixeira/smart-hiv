# Physician - JSON Representation - WHO SMART Guidelines - HIV v0.4.4

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Physician**

## : Physician - JSON Representation

| |
| :--- |
| Draft as of 2026-03-03 |

[Raw json](ActorDefinition-Physician.json) | [Download](ActorDefinition-Physician.json)

